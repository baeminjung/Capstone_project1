import pymysql

MYSQL_HOST = 'localhost'
MYSQL_CONN = pymysql.connect(
    host=MYSQL_HOST,
    port=3306,
    user='jdbctster',
    passwd='4002017',
    db='webmail',
    charset='utf8'
)


def conn_mysqldb():  # 재접속
    if not MYSQL_CONN.open:
        MYSQL_CONN.ping(reconnect=True)
    return MYSQL_CONN


'''
db = conn.cursor()

userId = 'asdf'
password = '1234'
name = 'asfdasdf'

sql = "INSERT INTO user_info (id, password, name) VALUES ('%s', '%s', '%s')" % (
    str(userId), str(password), str(name))
db.execute(sql)
db.commit()
'''

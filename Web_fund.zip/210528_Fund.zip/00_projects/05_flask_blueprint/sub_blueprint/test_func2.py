def test2():
    return 'test2'

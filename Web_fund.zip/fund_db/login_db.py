from flask import Flask, url_for, session, Blueprint, render_template, request, redirect, flash
import pymysql
from werkzeug.utils import redirect
from fund_db import mysql

login = Blueprint('login', __name__)


@login.route('/home')
def home():
    if "userID" in session:  # 로그인 됐을 때
        return render_template("index.html", username=session["userID"], login_result=True)
    else:  # 로그인 안됐을 때
        return render_template("index.html", login_result=False)


@ login.route('/login_user', methods=['POST'])
def login_user():
    if request.method == 'POST':
        userid = request.form["userid"]
        userpw = request.form["password"]
        # connection DB
        conn = mysql.MYSQL_CONN
        cursor = conn.cursor()
        sql = "SELECT * FROM user_info where id = '%s' " % userid

        cursor.execute(sql)
        row = cursor.fetchone()
        row_count = cursor.rowcount

        # row[0]: id, row[1]: password, row[2]:name
        # row값 존재하고, id, pw 일치하면
        if (row_count != 0) and (userid == row[0] and userpw == row[1]):
            session["userID"] = row[0]
            return redirect("/login/home")

        else:
            flash("아이디와 비밀번호를 다시 확인해주십시오.")
            return redirect("/login.html")

        conn.close()
    else:
        return "잘못된 접근입니다."


@ login.route("/logout")
def logout():
    session.pop('userID', None)
    return redirect("/login/home")

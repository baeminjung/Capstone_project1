from flask import Flask, url_for, session, Blueprint, render_template, request, redirect, flash
import pymysql
from werkzeug.utils import redirect
from fund_db import mysql, login_db

delete = Blueprint('delete', __name__)


# 비밀번호 수정
@delete.route('/edit', methods=['POST'])
def edit():
    if request.method == 'POST':
        userid = request.form['userid']
        edit_password = request.form['password']
        ck_password = request.form['ck_password']

        # 1. Null 값 확인
        if not(edit_password and ck_password):
            flash("빈칸을 채워주세요.")
            return render_template("mypage.html")

        else:
            pass

        # 2. 비밀번호 확인
        if (len(edit_password) > 12) or (len(edit_password) < 6):
            flash("비밀번호는 6자리이상 12자리 이하로 설정해주십시오.")
            return render_template("mypage.html")

        elif edit_password != ck_password:
            flash("비밀번호가 일치하지 않습니다.")
            return render_template("mypage.html")

        else:  # 비밀번호 수정
            # connection DB
            conn = mysql.MYSQL_CONN
            cursor = conn.cursor()
            sql = "UPDATE user_info SET password = '%s' where id = '%s'" % (str(
                edit_password), str(userid))

            cursor.execute(sql)
            conn.commit()
            flash("비밀번호가 변경되었습니다. 변경된 비밀번호로 로그인 해주십시오.")
            return render_template("index.html")

        conn.close()

    else:
        return "잘못된 접근입니다."

# 탈퇴


@delete.route('/delete_user', methods=['POST'])
def delete_user():
    if request.method == 'POST':
        userid = request.form['userid']

        # connection DB
        conn = mysql.MYSQL_CONN
        cursor = conn.cursor()
        sql = "DELETE FROM user_info where id = '%s' " % userid

        cursor.execute(sql)
        conn.commit()
        flash("탈퇴 완료되었습니다.")
        return render_template("index.html")

        conn.close()

    else:
        return "잘못된 접근입니다."

from flask import Flask, Blueprint, render_template, request, flash
import pymysql
from fund_db import mysql
#from fund_view import mysql

signup = Blueprint('signup', __name__)


@signup.route('/get_id', methods=['POST'])
def get_id():
    if request.method == 'POST':
        userid = request.form['userid']
        password = request.form['password']
        ck_password = request.form['ck_password']
        name = request.form['name']

        # Connection DB
        conn = mysql.MYSQL_CONN
        cursor = conn.cursor()

        sql = "SELECT * FROM user_info where id = '%s' " % userid
        cursor.execute(sql)
        row_count = cursor.rowcount

        # 1. 중복 아이디 검사
        if row_count != 0:
            flash("아이디가 이미 존재합니다.")
            return render_template("signup.html")
        else:
            pass

        # 2. Null값 확인
        if not(userid and password and ck_password and name):
            flash("빈칸을 채워주세요.")
            return render_template("signup.html")
        else:
            pass

        # 3. 비밀번호 검사
        if (len(password) > 12) or (len(password) < 6):
            flash("비밀번호는 6자리이상 12자리 이하로 설정해주십시오.")
            return render_template("signup.html")

        elif password != ck_password:
            flash("비밀번호가 일치하지 않습니다.")
            return render_template("signup.html")

        else:  # 회원가입 성공
            sql = "INSERT INTO user_info(id, password, name) VALUES ('%s', '%s', '%s')" % (
                str(userid), str(password), str(name))

            cursor.execute(sql)
            conn.commit()
            flash("회원가입이 완료되었습니다.")
            return render_template("signup.html")

        conn.close()

    else:
        return "잘못된 접근입니다."

import test

print ('start.py __name__:', test.add_one(10))
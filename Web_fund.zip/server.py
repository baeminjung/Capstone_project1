﻿# -*- coding: utf-8 -*-

from flask import Flask, render_template, request
from fund_db import signup_db, login_db, delete_db
from flask.templating import render_template_string
import pandas as pd
import matplotlib.pyplot as plt
from fbprophet import Prophet
from werkzeug.wrappers import Request, Response
import os

app = Flask(__name__)
app.secret_key = 'why would I tell you my secret key?'

# BluePrint
# 회원가입
app.register_blueprint(signup_db.signup, url_prefix="/signup")
# 로그인
app.register_blueprint(login_db.login, url_prefix="/login")
# 마이페이지
app.register_blueprint(delete_db.delete, url_prefix="/delete")


@app.route("/", methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/post', methods=['GET', 'POST'])
def post():
    if request.method == 'POST':    #post형식으로 가져오면
        value = request.form['num'] #num을 가져와서 
        value = int(value)          #int로 형변환한다.

        #fund_번호 로 이루어진 형태이므로 입력한 값에 따라 다른 값을 읽는다.
        df = pd.read_csv('./static/fund/fund_%d.csv' %value) 
        df = df[['date', 'rate']].dropna() # 가로 date, 세로 rate
        df['date'] = pd.to_datetime(df['date']) #첫 열은 날짜이기 때문에 날짜 형태로
        df = df.set_index('date')
        daily_df = df.resample('d').mean()
        d_df = daily_df.reset_index().dropna()

        d_df.columns = ['ds', 'y']
        fig = plt.figure(facecolor='w', figsize=(20, 6))

        m = Prophet() #프로펫사용
        m.fit(d_df)
        future = m.make_future_dataframe(periods=500) # 미래 500일까지 더 예측
        forecast = m.predict(future)
        forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail()

        #미래 예측
        from datetime import datetime, timedelta
        fig1 = m.plot(forecast)
        datenow = datetime.now()
        dateend = datenow + timedelta(days=100)
        datestart = dateend - timedelta(days=450)

        plt.xlim([datestart, dateend])
        plt.title("%d fund recommend" %value, fontsize=20)
        plt.xlabel("Day", fontsize=20)
        plt.ylabel("price", fontsize=20)
        plt.axvline(datenow, color="k", linestyle=":")
        plt.rcParams["figure.figsize"] = (7,4)

        file = "./static/fund/fund.png"
        if os.path.isfile(file): #만약 이미 만들어진 fund.png있으면 삭제
            os.remove(file)
        plt.savefig('./static/fund/fund.png', bbox_inches = 'tight', pad_inches = 0) #무조건 plt.show이전에
    return render_template('predict.html')

@app.route("/fundsearch.html", methods=['GET', 'POST'])
def fundSearch():
    return render_template('fundsearch.html')

@app.route("/predict.html", methods=['GET', 'POST'])
def fundTest():
    return render_template('predict.html')

@app.route("/analysis.html", methods=['GET', 'POST'])
def fundPredict():
    if request.method == 'GET':
        return render_template('analysis.html')
    if request.method == 'POST':
        answer1 = float(request.form['answer1'])
        answer2 = float(request.form['answer2'])
        answer3 = float(request.form['answer3'])
        answer4 = float(request.form['answer4'])
        answer5 = float(request.form['answer5'])
        answer6 = float(request.form['answer6'])
        answer7 = float(request.form['answer7'])

        cal = answer1 + answer2 + answer3 + answer4 + answer5 + answer6 + answer7

        if cal <= 20:
            tendency = '안정형'
        elif cal > 20 and cal <= 40:
            tendency = '안정추구형'
        elif cal > 40 and cal <= 60:
            tendency = '위험중립형'
        elif cal > 60 and cal <= 80:
            tendency = '적극투자형'
        elif cal > 80:
            tendency = '공격투자형'

        return render_template('result.html', tendency=tendency)

@app.route("/result.html", methods=['GET', 'POST'])
def tendencyResult():
    if request.method == 'GET':
        return render_template('result.html')
    if request.method == 'POST':
        correct = request.form['correct']

        if correct == '안정형':
            result = 5
        elif correct == '안정추구형':
            result = 4
        elif correct == '위험중립형':
            result = 3
        elif correct == '적극투자형':
            result = 2
        elif correct == '공격투자형':
            result = 1

        return render_template('ana_result.html', result=result)


@app.route("/login.html", methods=['GET', 'POST'])
def fundLogin():
    return render_template('login.html')

@app.route("/signup.html", methods=['GET', 'POST'])
def fundSignUp():
    return render_template('signup.html')

@ app.route("/mypage.html", methods=['GET', 'POST'])
def MyPage():
    return render_template('mypage.html')

@app.route("/ana_result.html", methods=['GET', 'POST'])
def fundResult():
    return render_template('ana_result.html')

if __name__ == '__main__':
    app.run(port=8016, debug=True)

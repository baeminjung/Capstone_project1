import numpy as np
from datetime import datetime, timedelta
from io import BytesIO, StringIO
from flask import Flask, send_file

import pandas as pd
import matplotlib as plt
from fbprophet import Prophet

# flask와 matplotlib연동
# 미래 예측

app = Flask(__name__)


@app.route('/<int:num>', methods=['GET'])
def fig(num):
    df = pd.read_csv('fund_%d.csv' % num)
    df = df[['date', 'rate']].dropna()
    df['date'] = pd.to_datetime(df['date'])
    df = df.set_index('date')
    daily_df = df.resample('d').mean()
    d_df = daily_df.reset_index().dropna()

    d_df.columns = ['ds', 'y']
    fig = plt.figure(facecolor='w', figsize=(20, 6))
    #plt.plot(d_df.ds, d_df.y)

    m = Prophet()
    m.fit(d_df)
    future = m.make_future_dataframe(periods=500)  # 미래 500일까지 더 예측
    forecast = m.predict(future)
    forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail()

# 미래예측
    fig1 = m.plot(forecast)

    #datenow = datetime.now()
    datenow = datetime(2021, 6, 1)
    dateend = datenow + timedelta(days=100)
    datestart = dateend - timedelta(days=450)

    img = BytesIO()
    plt.savefig(img, format='png', dpi=200)

    img.seek(0)
    return send_file(img, mimetype='image/png')


if __name__ == '__main__':
    app.run()
